package com.willianmendesf.bookstoremanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoremanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
