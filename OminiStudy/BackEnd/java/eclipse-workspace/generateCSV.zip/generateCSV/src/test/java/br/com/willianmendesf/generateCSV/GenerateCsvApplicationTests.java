package br.com.willianmendesf.generateCSV;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenerateCsvApplicationTests {

	@Test
	void contextLoads() {
	}

}
