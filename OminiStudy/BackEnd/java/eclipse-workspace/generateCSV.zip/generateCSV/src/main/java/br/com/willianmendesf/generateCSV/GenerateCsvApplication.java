package br.com.willianmendesf.generateCSV;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenerateCsvApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenerateCsvApplication.class, args);
	}

}
